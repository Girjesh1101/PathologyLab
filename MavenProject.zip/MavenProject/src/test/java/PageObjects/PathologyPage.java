package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

public class PathologyPage {
	
	public WebDriver driver;
	
	
	public PathologyPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name ="email")
	private WebElement txtBoxUserName;
	
	@FindBy(name = "password")
	private WebElement txtBoxPassword;
	
	@FindBy(xpath = "//button//span[text()='Login']")
	private WebElement loginBtn;
	
	@FindBy(xpath ="//div[@class='title']")
	private WebElement lblDashboard;
	
	@FindBy(xpath ="//div[text()='TODO']")
	private WebElement lblToDo;
	
	@FindBy(xpath ="//div[text()='Test Cost Calculator']")
	private WebElement lblTestCostcalculator;
	
	
	public SoftAssert login(String userId, String pass) throws InterruptedException {
		
		SoftAssert softAssert = new SoftAssert();
		
		try {
			
		
			txtBoxUserName.sendKeys(userId);
			txtBoxPassword.sendKeys(pass);
			Thread.sleep(3000);
			loginBtn.click();
		
			String homeLebel = lblDashboard.getText();
			System.out.println("Verify if Dashboard is Visible : "+lblDashboard.isDisplayed());
			softAssert.assertEquals(homeLebel,"Dashboard","Verify if we reach home page");
		
			String toDoLebl = lblToDo.getText();
			System.out.println("Verify if TODOs List Visible : "+lblToDo.isDisplayed());
			softAssert.assertEquals(toDoLebl,"TODO" ,"Verify if TODO list visible");
		
			String testCostCal = lblTestCostcalculator.getText();
			System.out.println("Verify if Test Cost Calculator Visible : "+lblTestCostcalculator.isDisplayed());
			softAssert.assertEquals(testCostCal,"Test Cost Calculator" ,"Verify if Test cost Calculator is visible");
			
		} catch (Exception e) {
			
			System.out.println("Error Found  : "+e.getMessage());
		}
		
		return softAssert;
	}

}
