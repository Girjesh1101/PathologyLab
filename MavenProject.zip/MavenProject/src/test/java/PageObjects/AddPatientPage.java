package PageObjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class AddPatientPage {
	
	public WebDriver driver;
	
	
	public AddPatientPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "(//ul/a)[2]")
	public WebElement testBtn;
	
	@FindBy(xpath = "//button[@type='submit']")
	public WebElement addPatientsBtn;
	
	@FindBy(name= "name")
	private WebElement txtBoxPatientName;
	
	@FindBy(name ="email")
	private WebElement txtBoxEmail;
	
	@FindBy(name ="phone")
	private WebElement txtBoxPhone;
	
	@FindBy(xpath ="(//button[@type='button'])[4]")
	private WebElement generateDetailsBtn;
	
	@FindBy(name ="height")
	private WebElement txtBoxHeight;
	
	@FindBy(name ="weight")
	private WebElement txtBoxWeight;
	
	@FindBy(id ="mui-component-select-gender")
	private WebElement genderBtn;
	
	@FindBy(xpath = "//li[@role='option']")
	private List<WebElement> genderoption;
	
	@FindBy(name ="age")
	private WebElement txtBoxAge;
	
	@FindBy(name ="systolic")
	private WebElement txtBoxSystolic;
	
	@FindBy(name ="diastolic")
	private WebElement txtBoxDiastolic;
	
	@FindBy(xpath ="(//button[@type='button'])[4]")
	private WebElement addTestBtn;
	
	
	public void patientsDetails(String name , String email , String phone) throws InterruptedException {
		
		
		addPatientsBtn.click();
		Thread.sleep(3000);
		
		txtBoxPatientName.sendKeys(name);
		txtBoxEmail.sendKeys(email);
		txtBoxPhone.sendKeys(phone);
		
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//		wait.until(ExpectedConditions.elementToBeClickable(generateDetailsBtn));
		
		Thread.sleep(3000);
		generateDetailsBtn.click();
	}
	
	public void secondryDetails(String height, String weight ,String age, String gender, String systolic , String diastolic) {
		
		txtBoxHeight.sendKeys(height);
		txtBoxWeight.sendKeys(weight);
		txtBoxAge.sendKeys(age);
		
		try {
			
			genderBtn.click();
			
			for(WebElement ele : genderoption) {
				
				if(ele.getAttribute("data-value").equalsIgnoreCase(gender)) {
					
					ele.click();
				}
			}
			
		} catch (Exception e) {
			
			System.out.println("Gender Not Found : "+e.getMessage());
			
		}
		
		txtBoxSystolic.sendKeys(systolic);
		txtBoxDiastolic.sendKeys(diastolic);
		
		addTestBtn.click();
		
	}
	
	@FindBy(id ="patient-tests-labs")
	private WebElement txtBoxPatientTestsLabs;
	
	@FindBy(xpath ="//li[@role='option']")
	private List< WebElement > allSuggestion; 
	
	@FindBy(name ="doctor_name")
	private WebElement txtBoxDoctor;
	
	@FindBy(xpath ="//button[@title='Add equipment']")
	private WebElement addEquipmentBtn;
	
	@FindBy(xpath ="(//tbody//button[@type='button'])[1]")
	private WebElement doneBtn;
	
	@FindBy(xpath ="(//div[@class='jss125']//button[@type='button'])[2]")
	private WebElement addPatientBtn;
	
	
	public void testCostCalculatorForPatient(String Product, String discount  ,String labName , String docName) throws InterruptedException {
		
		CostCalculatorPage obj = new CostCalculatorPage(driver);
		
		obj.selectMedicine(Product, discount);
		
		try {
			txtBoxPatientTestsLabs.sendKeys(labName);
			
			for(WebElement ele : allSuggestion) {
				
				String name = ele.getText();
				System.out.println(name);
				Thread.sleep(300);
				ele.click();
			}
			
			txtBoxDoctor.sendKeys(docName);
			
			for(WebElement ele : allSuggestion) {
				
				String name = ele.getText();
				System.out.println(name);
				Thread.sleep(300);
				ele.click();
			}
			
		} catch (Exception e) {
			
			System.out.println("not found lab :"+e.getMessage());
		}
		
		
		addEquipmentBtn.click();
		Thread.sleep(300);
		doneBtn.click();
		Thread.sleep(200);
		addPatientBtn.click();
		
	}
		
	

}
