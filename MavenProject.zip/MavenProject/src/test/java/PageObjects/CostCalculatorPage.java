package PageObjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class CostCalculatorPage {
	
	public WebDriver driver;
	
	
	public CostCalculatorPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath ="//div[text()='Test Cost Calculator']")
	private WebElement lblTestCostcalculator;
	
	@FindBy(id ="patient-test")
	private WebElement txtBoxMedicine;
	
	@FindBy(xpath ="//li[@role='option']")
	private List< WebElement > allSuggestion; 
	
	@FindBy(xpath ="//div[@role='button']/em")
	private WebElement discountBtn;
	
	@FindBy(xpath ="//li[@role='option']")
	private List<WebElement> allDiscounts;
	
	
	public  void selectMedicine(String medicineName, String discount) throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", lblTestCostcalculator);
		txtBoxMedicine.sendKeys(medicineName);
		
		for(WebElement ele : allSuggestion) {
			
			String name = ele.getText();
			System.out.println(name);
			Thread.sleep(300);
			ele.click();
		}
		
		Thread.sleep(3000);
		
		discountBtn.click();
		
		for(WebElement dis : allDiscounts) {
			
			if(dis.getAttribute("data-value").equalsIgnoreCase(discount)) {
				
				dis.click();
			}
		}
		
		
	}

}
