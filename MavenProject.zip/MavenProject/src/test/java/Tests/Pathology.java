package Tests;

import org.testng.annotations.Test;

import PageObjects.AddPatientPage;
import PageObjects.CostCalculatorPage;
import PageObjects.PathologyPage;

public class Pathology extends BaseTest{

	
	//@Test
	public void test() throws InterruptedException {
		
		
		driver.get(prop.getProperty("url"));
		
		PathologyPage object = new PathologyPage(driver);
		
		object.login(prop.getProperty("username"), prop.getProperty("password"));
		
		Thread.sleep(3000);
		CostCalculatorPage calculatorPage = new CostCalculatorPage(driver);
		calculatorPage.selectMedicine(prop.getProperty("product"),prop.getProperty("discount"));
	}
	
	@Test
	public void test2() throws InterruptedException {
		
		
		driver.get(prop.getProperty("url"));
		
		PathologyPage object = new PathologyPage(driver);
		
		object.login(prop.getProperty("username"), prop.getProperty("password"));
		
		Thread.sleep(3000);
		AddPatientPage patientPage = new AddPatientPage(driver);
		patientPage.testBtn.click();
		Thread.sleep(3000);
		patientPage.patientsDetails("a","aer@aerem.com","9876543344");
		Thread.sleep(3000);
		patientPage.secondryDetails("150", "72","34", "male",  "80", "100");
	}
}
