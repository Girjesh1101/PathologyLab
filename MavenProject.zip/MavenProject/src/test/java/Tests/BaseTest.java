package Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {
	
	
	public static WebDriver driver;
	public static String browser;
	public static String configPath;
	public static String env;
	public static Properties prop;
	
	
	@BeforeSuite
	public void setProperties() throws IOException {
		
		// read browser property
		browser = System.getProperty("browser");
		
		//read env property
		env = System.getProperty("env");
		
		// read configPath property
		configPath = System.getProperty("config");
		
		setEnvornment();
		
	}
	
	@BeforeMethod
	public void setBroswer() {
		
		if(browser.equalsIgnoreCase("chrome")) {
			
			driver = new ChromeDriver();
			System.out.println("Starting Chrome Broswer");
			
		}else if(browser.equalsIgnoreCase("firefox")) {
			
			driver = new FirefoxDriver();
			System.out.println("Starting FireFox Broswer");
		}else {
			
			System.out.println("Not Found any Broswer...!!");
			System.exit(1);
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(35));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(45));
	}
	
	public void setEnvornment() throws IOException {
		
		FileInputStream inStream = null;
		
		if(env.equalsIgnoreCase("staging") || env.equalsIgnoreCase("dev")) {
			
			inStream = new FileInputStream(new File(configPath+"\\"+env+".properties"));
		}else {
			
			System.out.println("Environment invalid. Please provide either staging or dev");
			System.exit(1);
		}
		
		System.out.println("read Properties File");
		
		prop = new Properties();
		
		prop.load(inStream);
	}

}
